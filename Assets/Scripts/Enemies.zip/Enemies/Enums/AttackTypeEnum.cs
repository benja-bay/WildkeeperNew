namespace Enemies
{
    public enum AttackType
    {
        Melee,
        Range,
    }
}
namespace Enemies
{
    public enum BehaviorType
    {
        Idle,
        Patrol,
        Chase,
        Flee,
        Dead,
        Charge
    }
}